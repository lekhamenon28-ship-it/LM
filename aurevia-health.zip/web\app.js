const $ = (s) => document.querySelector(s);
const money = (n) => n == null ? 'Pending' : new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(n);
const get = async path => { const r = await fetch(path); if(!r.ok) throw new Error(); return r.json(); };
const toast = msg => { const el=$('#toast'); el.textContent=msg; el.classList.add('show'); setTimeout(()=>el.classList.remove('show'),2600); };

async function load(){
  try {
    const [member, claims, care] = await Promise.all([get('/api/member/'),get('/api/claims/'),get('/api/care/')]);
    const first=member.name.split(' ')[0];
    $('#first-name').textContent=$('#short-name').textContent=first; $('#avatar').textContent=member.initials;
    $('#plan').textContent=$('#card-plan').textContent=member.plan; $('#member-id').textContent=$('#card-id').textContent=member.id; $('#card-name').textContent=member.name;
    $('#deductible-label').textContent=`${money(member.deductible.used)} of ${money(member.deductible.total)}`;
    $('#oop-label').textContent=`${money(member.outOfPocket.used)} of ${money(member.outOfPocket.total)}`;
    $('#deductible-bar').style.width=`${member.deductible.used/member.deductible.total*100}%`; $('#oop-bar').style.width=`${member.outOfPocket.used/member.outOfPocket.total*100}%`;
    $('#score').textContent=care.healthScore;
    $('#tasks').innerHTML=care.tasks.map(t=>`<article class="task ${t.complete?'done':''}"><span class="task-check">${t.complete?'✓':''}</span><div><b>${t.title}</b><p>${t.detail}</p><em>${t.due}</em></div></article>`).join('');
    $('#claims').innerHTML=claims.claims.map(c=>`<tr><td><b>${c.provider}</b><small>${c.service} · ${c.id}</small></td><td>${c.date}</td><td><span class="status ${c.status==='In review'?'review':''}">${c.status}</span></td><td>${money(c.billed)}</td><td><b>${money(c.youPay)}</b></td></tr>`).join('');
  } catch { toast('Some health data is temporarily unavailable.'); }
}

document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.nav').forEach(n=>n.classList.toggle('active',n.dataset.view===b.dataset.view)); const target=b.dataset.view==='claims'?'#claims':b.dataset.view==='care'?'#tasks':b.dataset.view==='find-care'?'#provider-search':'.hello'; $(target).scrollIntoView({behavior:'smooth',block:'center'});}));
$('#id-card').onclick=()=>$('#modal').showModal(); $('.close').onclick=()=>$('#modal').close();
$('#provider-search').onsubmit=async e=>{e.preventDefault(); const area=$('#providers'); area.classList.add('show'); area.innerHTML='<div class="skeleton"></div>'; try{const d=await get('/api/providers/'); area.innerHTML=d.providers.map(p=>`<article class="provider"><b>${p.name}</b><small>${p.specialty} · ${p.distance} · ★ ${p.rating}</small><em>${p.available}</em></article>`).join('');}catch{area.innerHTML='Unable to load providers.';}};
load();

