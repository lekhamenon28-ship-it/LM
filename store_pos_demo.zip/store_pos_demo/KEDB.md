# KEDB-1021 — Checkout DB Connection Pool Exhaustion

## Symptoms
- Checkout response time increases sharply.
- HTTP 503 responses appear.
- Application log contains `DB_CONNECTION_POOL_TIMEOUT`.
- Host CPU and memory may remain normal.

## Known cause
Insufficient database connection pool capacity for concurrent checkout traffic.

## Resolution
1. Confirm connection pool saturation.
2. Review recent checkout-service configuration changes.
3. Restore the approved connection pool setting.
4. Run synthetic checkout transactions.
5. Verify latency and failure rate return to normal.
