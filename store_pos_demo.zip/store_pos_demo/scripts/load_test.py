import argparse, random, time
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests

def one_checkout(base_url, idx):
    payload={"store":"STORE-001","terminal":f"POS-{(idx%10)+1:02d}","items":[{"id":1},{"id":2},{"id":5}],"amount":round(random.uniform(150,2500),2)}
    t0=time.perf_counter()
    try:
        r=requests.post(f"{base_url}/api/checkout",json=payload,timeout=15)
        elapsed=(time.perf_counter()-t0)*1000
        body=r.json()
        return r.status_code,elapsed,body.get("status"),body.get("error")
    except Exception as e:
        elapsed=(time.perf_counter()-t0)*1000
        return 0,elapsed,"ERROR",str(e)

def main():
    p=argparse.ArgumentParser(); p.add_argument("--url",default="http://127.0.0.1:5000"); p.add_argument("--users",type=int,default=20); p.add_argument("--requests",type=int,default=50); args=p.parse_args()
    results=[]
    with ThreadPoolExecutor(max_workers=args.users) as ex:
        futures=[ex.submit(one_checkout,args.url,i) for i in range(args.requests)]
        for f in as_completed(futures): results.append(f.result())
    ok=sum(1 for s,_,_,_ in results if s==200); failed=len(results)-ok; lat=[x[1] for x in results]
    print(f"Total: {len(results)}\nSuccess: {ok}\nFailed: {failed}\nSuccess rate: {ok/len(results)*100:.1f}%\nAvg latency: {sum(lat)/len(lat):.1f} ms\nMax latency: {max(lat):.1f} ms")
    errors={}
    for _,_,_,e in results:
        if e: errors[e]=errors.get(e,0)+1
    if errors: print("Errors:",errors)
if __name__=="__main__": main()
