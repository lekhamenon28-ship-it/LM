# Store POS Observability Demo

A small POS/checkout application for an observability + Agentic AI demo. It runs directly on a Linux VM or laptop; no Docker is required.

## What it demonstrates

Healthy flow: POS UI -> Checkout API -> SQL database -> SUCCESS.

Failure flow: switch to failure mode -> connection pool drops from 20 to 2 -> checkout requests hold DB connections for 2.5s -> concurrent requests exhaust the pool -> HTTP 503 + `DB_CONNECTION_POOL_TIMEOUT` -> structured logs and a configuration change record are generated.

## Install

```bash
cd store_pos_demo
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open `http://<VM-IP>:5000`.

## Healthy test

```bash
python scripts/load_test.py --users 5 --requests 20
curl http://127.0.0.1:5000/api/metrics
```

## Trigger the failure

Either click **Trigger DB pool failure** in the UI or run:

```bash
curl -X POST http://127.0.0.1:5000/admin/mode \
  -H "Content-Type: application/json" \
  -d '{"mode":"failure"}'
```

Then generate concurrent checkout traffic:

```bash
python scripts/load_test.py --users 25 --requests 50
```

Inspect:

```bash
curl http://127.0.0.1:5000/api/metrics
tail -f logs/pos.log
cat changes.json
```

## Restore

```bash
curl -X POST http://127.0.0.1:5000/admin/mode \
  -H "Content-Type: application/json" \
  -d '{"mode":"healthy"}'
```

## Useful endpoints

- `/` POS UI
- `/health`
- `/api/products`
- `/api/checkout`
- `/api/metrics`
- `/api/changes`
- `/admin/status`
- `/admin/mode`

## Observability story

Monitor the Python process, `/api/checkout`, HTTP 503s, response time, `logs/pos.log`, CPU and memory.

During failure you should see: host CPU normal, memory normal, checkout latency high, checkout failures high, log errors showing `DB_CONNECTION_POOL_TIMEOUT`, and a recent pool configuration change.

The included `KEDB.md`, `SOP_checkout_pool.md`, `past_incidents.json`, and `changes.json` can later be used by the Agentic AI RCA layer.
