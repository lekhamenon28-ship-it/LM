# SOP — Checkout Service Connection Pool Incident

1. Confirm checkout failure rate and latency.
2. Check host CPU, memory and network health.
3. Search checkout logs for DB connection timeout errors.
4. Check recent configuration changes.
5. Compare with KEDB-1021.
6. If approved, restore the healthy pool configuration.
7. Run at least five synthetic checkout transactions.
8. Verify success rate >99%, latency <2 seconds, and no new pool timeout errors.
9. Update the incident with root cause, action and verification evidence.
