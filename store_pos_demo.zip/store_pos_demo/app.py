import json
import logging
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

from flask import Flask, jsonify, render_template, request
from sqlalchemy import create_engine, text
from sqlalchemy.exc import TimeoutError as SATimeoutError
from sqlalchemy.pool import QueuePool

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "pos_demo.db"
CHANGE_LOG = BASE_DIR / "changes.json"
LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(exist_ok=True)

app = Flask(__name__)

logger = logging.getLogger("store-pos")
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.FileHandler(LOG_DIR / "pos.log")
    handler.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(handler)

def log_event(event_type, **kwargs):
    payload = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "event_type": event_type,
        "service": "checkout-service",
        "store": kwargs.pop("store", "STORE-001"),
        **kwargs,
    }
    logger.info(json.dumps(payload))

engine_lock = threading.Lock()
engine = None
POOL_SIZE = 20
POOL_TIMEOUT = 2.0
HOLD_SECONDS = 0.08
MODE = "healthy"

metrics_lock = threading.Lock()
metrics = {
    "requests": 0,
    "success": 0,
    "failed": 0,
    "total_latency_ms": 0.0,
    "last_latency_ms": 0.0,
    "last_error": None,
}

PRODUCTS = [
    {"id": 1, "name": "Rice 5 kg", "price": 420.0},
    {"id": 2, "name": "Milk 1 L", "price": 68.0},
    {"id": 3, "name": "Bread", "price": 45.0},
    {"id": 4, "name": "Coffee 200 g", "price": 310.0},
    {"id": 5, "name": "Apples 1 kg", "price": 180.0},
    {"id": 6, "name": "Soap", "price": 55.0},
]

def make_engine(pool_size: int, pool_timeout: float):
    return create_engine(
        f"sqlite:///{DB_PATH}",
        connect_args={"check_same_thread": False},
        poolclass=QueuePool,
        pool_size=pool_size,
        max_overflow=0,
        pool_timeout=pool_timeout,
        future=True,
    )

def init_db(current_engine):
    with current_engine.begin() as conn:
        conn.execute(text("""
            CREATE TABLE IF NOT EXISTS transactions (
                id TEXT PRIMARY KEY,
                store TEXT NOT NULL,
                terminal TEXT NOT NULL,
                amount REAL NOT NULL,
                items INTEGER NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """))

def rebuild_engine(pool_size: int, pool_timeout: float):
    global engine
    with engine_lock:
        old = engine
        engine = make_engine(pool_size, pool_timeout)
        init_db(engine)
        if old is not None:
            old.dispose()

def append_change(old_mode, new_mode, old_pool, new_pool):
    existing = []
    if CHANGE_LOG.exists():
        try:
            existing = json.loads(CHANGE_LOG.read_text())
        except Exception:
            existing = []
    existing.append({
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "service": "checkout-service",
        "change": "DB_CONNECTION_POOL_MODE",
        "old_mode": old_mode,
        "new_mode": new_mode,
        "old_pool_size": old_pool,
        "new_pool_size": new_pool,
        "changed_by": "demo-admin",
    })
    CHANGE_LOG.write_text(json.dumps(existing, indent=2))

def configure_mode(mode: str):
    global POOL_SIZE, POOL_TIMEOUT, HOLD_SECONDS, MODE
    if mode not in ("healthy", "failure"):
        raise ValueError("mode must be 'healthy' or 'failure'")

    old_mode = MODE
    old_pool = POOL_SIZE

    if mode == "healthy":
        POOL_SIZE = 20
        POOL_TIMEOUT = 2.0
        HOLD_SECONDS = 0.08
    else:
        POOL_SIZE = 2
        POOL_TIMEOUT = 0.5
        HOLD_SECONDS = 2.5

    MODE = mode
    rebuild_engine(POOL_SIZE, POOL_TIMEOUT)
    append_change(old_mode, mode, old_pool, POOL_SIZE)
    log_event(
        "configuration_change",
        old_mode=old_mode,
        new_mode=mode,
        old_pool_size=old_pool,
        new_pool_size=POOL_SIZE,
        hold_seconds=HOLD_SECONDS,
    )

rebuild_engine(POOL_SIZE, POOL_TIMEOUT)

@app.get("/")
def index():
    return render_template("index.html", products=PRODUCTS)

@app.get("/health")
def health():
    return jsonify({
        "status": "UP",
        "service": "checkout-service",
        "mode": MODE,
        "pool_size": POOL_SIZE,
        "pool_timeout_s": POOL_TIMEOUT,
        "hold_seconds": HOLD_SECONDS,
    })

@app.get("/api/products")
def products():
    return jsonify(PRODUCTS)

@app.get("/api/metrics")
def get_metrics():
    with metrics_lock:
        m = dict(metrics)
    avg = (m["total_latency_ms"] / m["requests"]) if m["requests"] else 0
    success_rate = (m["success"] / m["requests"] * 100) if m["requests"] else 100
    failure_rate = (m["failed"] / m["requests"] * 100) if m["requests"] else 0
    return jsonify({
        **m,
        "avg_latency_ms": round(avg, 1),
        "success_rate_pct": round(success_rate, 1),
        "failure_rate_pct": round(failure_rate, 1),
        "mode": MODE,
        "pool_size": POOL_SIZE,
        "hold_seconds": HOLD_SECONDS,
        "pool_checked_out": engine.pool.checkedout(),
        "pool_checked_in": engine.pool.checkedin(),
    })

@app.post("/api/metrics/reset")
def reset_metrics():
    with metrics_lock:
        metrics.update({
            "requests": 0,
            "success": 0,
            "failed": 0,
            "total_latency_ms": 0.0,
            "last_latency_ms": 0.0,
            "last_error": None,
        })
    return jsonify({"status": "reset"})

@app.post("/api/checkout")
def checkout():
    start = time.perf_counter()
    payload = request.get_json(silent=True) or {}
    store = payload.get("store", "STORE-001")
    terminal = payload.get("terminal", "POS-01")
    items = payload.get("items", [])
    amount = float(payload.get("amount", 0.0))

    with metrics_lock:
        metrics["requests"] += 1

    txn_id = f"TXN-{uuid.uuid4().hex[:8].upper()}"

    try:
        with engine.begin() as conn:
            conn.execute(
                text("""
                    INSERT INTO transactions
                    (id, store, terminal, amount, items, status, created_at)
                    VALUES (:id, :store, :terminal, :amount, :items, :status, :created_at)
                """),
                {
                    "id": txn_id,
                    "store": store,
                    "terminal": terminal,
                    "amount": amount,
                    "items": len(items) if isinstance(items, list) else int(items or 0),
                    "status": "PROCESSING",
                    "created_at": datetime.now(timezone.utc).isoformat(),
                },
            )
            time.sleep(HOLD_SECONDS)
            conn.execute(
                text("UPDATE transactions SET status='SUCCESS' WHERE id=:id"),
                {"id": txn_id},
            )

        latency_ms = (time.perf_counter() - start) * 1000
        with metrics_lock:
            metrics["success"] += 1
            metrics["total_latency_ms"] += latency_ms
            metrics["last_latency_ms"] = latency_ms
            metrics["last_error"] = None

        log_event(
            "checkout_success",
            store=store,
            terminal=terminal,
            transaction=txn_id,
            amount=amount,
            latency_ms=round(latency_ms, 1),
            pool_size=POOL_SIZE,
            pool_checked_out=engine.pool.checkedout(),
            mode=MODE,
        )
        return jsonify({
            "transaction": txn_id,
            "status": "SUCCESS",
            "response_time_ms": round(latency_ms, 1),
        })

    except SATimeoutError:
        latency_ms = (time.perf_counter() - start) * 1000
        msg = "Timeout waiting for database connection"
        with metrics_lock:
            metrics["failed"] += 1
            metrics["total_latency_ms"] += latency_ms
            metrics["last_latency_ms"] = latency_ms
            metrics["last_error"] = msg

        log_event(
            "checkout_failure",
            store=store,
            terminal=terminal,
            error="DB_CONNECTION_POOL_TIMEOUT",
            message=msg,
            latency_ms=round(latency_ms, 1),
            pool_size=POOL_SIZE,
            pool_checked_out=engine.pool.checkedout(),
            mode=MODE,
        )
        return jsonify({
            "status": "FAILED",
            "error": "DB_CONNECTION_POOL_TIMEOUT",
            "message": msg,
            "response_time_ms": round(latency_ms, 1),
        }), 503

    except Exception as exc:
        latency_ms = (time.perf_counter() - start) * 1000
        with metrics_lock:
            metrics["failed"] += 1
            metrics["total_latency_ms"] += latency_ms
            metrics["last_latency_ms"] = latency_ms
            metrics["last_error"] = str(exc)

        log_event(
            "checkout_failure",
            store=store,
            terminal=terminal,
            error=type(exc).__name__,
            message=str(exc),
            latency_ms=round(latency_ms, 1),
            mode=MODE,
        )
        return jsonify({
            "status": "FAILED",
            "error": type(exc).__name__,
            "message": str(exc),
        }), 500

@app.post("/admin/mode")
def admin_mode():
    payload = request.get_json(silent=True) or {}
    mode = payload.get("mode", "")
    try:
        configure_mode(mode)
        return jsonify({
            "status": "OK",
            "mode": MODE,
            "pool_size": POOL_SIZE,
            "pool_timeout_s": POOL_TIMEOUT,
            "hold_seconds": HOLD_SECONDS,
        })
    except ValueError as exc:
        return jsonify({"status": "ERROR", "message": str(exc)}), 400

@app.get("/admin/status")
def admin_status():
    return jsonify({
        "mode": MODE,
        "pool_size": POOL_SIZE,
        "pool_timeout_s": POOL_TIMEOUT,
        "hold_seconds": HOLD_SECONDS,
        "pool_checked_out": engine.pool.checkedout(),
        "pool_checked_in": engine.pool.checkedin(),
    })

@app.get("/api/changes")
def changes():
    if not CHANGE_LOG.exists():
        return jsonify([])
    try:
        return jsonify(json.loads(CHANGE_LOG.read_text()))
    except Exception:
        return jsonify([])

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)
