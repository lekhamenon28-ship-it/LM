#!/usr/bin/env python3
"""Collect and compare observability maturity across multiple tools."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

from adapters import ADAPTERS
from collector import Dataset, calculate_assessment, collect_live, load_fixture, write_outputs


def configured() -> list[str]:
    tools = []
    if os.getenv("DT_ENV_URL") and os.getenv("DT_API_TOKEN"): tools.append("dynatrace")
    if os.getenv("DD_API_KEY") and os.getenv("DD_APP_KEY"): tools.append("datadog")
    if os.getenv("ZABBIX_URL") and os.getenv("ZABBIX_TOKEN"): tools.append("zabbix")
    if os.getenv("SPLUNK_URL") and (os.getenv("SPLUNK_TOKEN") or (os.getenv("SPLUNK_USER") and os.getenv("SPLUNK_PASSWORD"))): tools.append("splunk")
    return tools


def merge(providers: dict[str, dict[str, Dataset]]) -> dict[str, Dataset]:
    names = sorted({name for datasets in providers.values() for name in datasets})
    merged = {}
    for name in names:
        sources = [(provider, datasets[name]) for provider, datasets in providers.items() if name in datasets]
        available = [(provider, ds) for provider, ds in sources if ds.status == "available"]
        data = []
        for provider, ds in available:
            values = ds.data if isinstance(ds.data, list) else [ds.data]
            for value in values:
                if isinstance(value, dict):
                    value = dict(value); value.setdefault("source", provider)
                data.append(value)
        status = "available" if available else (sources[0][1].status if sources else "unknown")
        errors = "; ".join(f"{p}: {d.error}" for p, d in sources if d.error)
        merged[name] = Dataset(status, data, "multi-provider", errors or None, sum(d.pages for _, d in sources))
    return merged


def args_parser():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--providers", default="auto", help="auto, all, or comma-separated: dynatrace,datadog,zabbix,splunk")
    parser.add_argument("--output", type=Path, default=Path("multi-out"))
    parser.add_argument("--from-time", default="now-30d"); parser.add_argument("--to-time", default="now")
    parser.add_argument("--management-zone"); parser.add_argument("--tag")
    parser.add_argument("--page-size", type=int, default=500); parser.add_argument("--timeout", type=int, default=30)
    parser.add_argument("--fixture-dir", type=Path, help="Directory containing <provider>.json fixtures")
    return parser.parse_args()


def main():
    args = args_parser()
    selected = configured() if args.providers == "auto" else list(ADAPTERS) + ["dynatrace"] if args.providers == "all" else [x.strip().lower() for x in args.providers.split(",")]
    if not selected: raise SystemExit("No configured provider found. Set credentials or pass --fixture-dir.")
    providers = {}
    diagnostics = {}
    for name in selected:
        try:
            fixture = args.fixture_dir / f"{name}.json" if args.fixture_dir else None
            if fixture and fixture.exists(): providers[name] = load_fixture(fixture)
            elif name == "dynatrace": providers[name] = collect_live(args)
            elif name in ADAPTERS: providers[name] = ADAPTERS[name](args.timeout)
            else: raise RuntimeError("Unsupported provider")
            diagnostics[name] = "collected"
        except Exception as exc:
            diagnostics[name] = f"failed: {exc}"
    if not providers: raise SystemExit("Every selected provider failed. Check credentials and URLs.")
    assessment = calculate_assessment(merge(providers), args)
    assessment["metadata"]["providers"] = selected
    assessment["providerDiagnostics"] = diagnostics
    assessment["providerInventory"] = {p: {"datasetsAvailable": sum(1 for d in ds.values() if d.status == "available"), "datasetsTotal": len(ds), "entities": len((ds.get("entities") or Dataset("x", [])).data or [])} for p, ds in providers.items()}
    write_outputs(assessment, args.output)
    (args.output / "provider-evidence.json").write_text(json.dumps({p: {k: {"status": v.status, "endpoint": v.endpoint, "error": v.error, "data": v.data} for k, v in ds.items()} for p, ds in providers.items()}, indent=2), encoding="utf-8")
    print(f"Multi-tool assessment complete: {args.output.resolve()}")
    print(json.dumps(assessment["providerInventory"], indent=2))


if __name__ == "__main__": main()

