# Dynatrace Observability Maturity Collector

Read-only, tenant-wide inventory and maturity assessment for Dynatrace. It discovers everything visible to the supplied token rather than targeting one cluster.

It also includes a vendor-neutral multi-tool runner for **Datadog, Zabbix, and Splunk**. Evidence is normalized for a combined maturity score while `provider-evidence.json` preserves the native evidence and provenance.

## Outputs

- `assessment.json` — complete evidence, scores, gaps, and API diagnostics
- `inventory.csv` — entity counts by type and health state
- `recommendations.csv` — prioritized improvements
- `report.html` — self-contained executive report

Missing permissions are reported as `unknown`; they do not become false zero scores.
The collector first reads the tenant's entity-type catalog and then paginates every type, because Dynatrace's monitored-entities endpoint requires an entity selector.

## Quick start

Python 3.10+ is required. There are no third-party dependencies.

PowerShell:

```powershell
$env:DT_ENV_URL = "https://YOUR_ENVIRONMENT.live.dynatrace.com"
$env:DT_API_TOKEN = "YOUR_READ_ONLY_TOKEN"
python collector.py --output ./out
```

## Multi-tool collection

Configure any combination of providers. `--providers auto` detects providers from their environment variables.

```powershell
# Dynatrace
$env:DT_ENV_URL="https://YOUR_ENVIRONMENT.live.dynatrace.com"
$env:DT_API_TOKEN="..."

# Datadog (change DD_SITE for EU, US3, US5, etc.)
$env:DD_SITE="https://api.datadoghq.com"
$env:DD_API_KEY="..."
$env:DD_APP_KEY="..."

# Zabbix
$env:ZABBIX_URL="https://zabbix.example.com/zabbix"
$env:ZABBIX_TOKEN="..."

# Splunk management API, normally port 8089
$env:SPLUNK_URL="https://splunk.example.com:8089"
$env:SPLUNK_TOKEN="..."

python multi_collector.py --providers auto --output ./multi-out
```

Or select explicit providers:

```powershell
python multi_collector.py --providers dynatrace,datadog,zabbix,splunk --output ./multi-out
```

Additional output: `provider-evidence.json` contains the evidence returned by each tool. A failed provider does not prevent other configured providers from completing.

Provider coverage:

| Provider | Evidence collected |
|---|---|
| Dynatrace | All entity types, metrics, problems, Settings 2.0, SLOs, synthetics, zones, alerting and notifications |
| Datadog | Hosts, metric catalog, monitors, SLOs, synthetics and notification evidence |
| Zabbix | Hosts, monitored item count, triggers, problems, templates, host groups and web scenarios |
| Splunk | Servers, indexes, saved searches, fired alerts, dashboards and alert actions |

Use read-only service identities. Datadog requires both an API key and an application key for read operations. Zabbix supports a bearer API token. Splunk supports a bearer token or `SPLUNK_USER` plus `SPLUNK_PASSWORD`.

Linux/macOS:

```bash
export DT_ENV_URL="https://YOUR_ENVIRONMENT.live.dynatrace.com"
export DT_API_TOKEN="YOUR_READ_ONLY_TOKEN"
python3 collector.py --output ./out
```

For this tenant, confirm in API Explorer whether the Environment API URL is:

```text
https://vri13969.live.dynatrace.com
```

Never commit or paste tokens into configuration files.

## Token permissions

Create a dedicated read-only API token. Enable the permissions available in your tenant that correspond to:

- `entities.read`
- `metrics.read`
- `problems.read`
- `settings.read`
- `slo.read`
- `ReadSyntheticData`
- `ReadConfig` (optional classic configuration coverage)

The collector probes each API independently and records HTTP 401/403 responses as permission gaps.

## Options

```text
--output DIR             Output directory (default: ./out)
--from-time VALUE        Assessment lookback (default: now-30d)
--to-time VALUE          Assessment end (default: now)
--management-zone NAME   Optional tenant inventory filter
--tag TAG                Optional entity tag filter
--page-size NUMBER       Entity page size, max 500 (default: 500)
--fixture FILE           Run from a saved fixture without a tenant/token
--save-fixture FILE      Save raw API responses for repeatable demos
```

Filters are optional. With no filter, the collector inventories the complete tenant scope visible to the token.

## Fixture demo

```bash
python collector.py --fixture sample-fixture.json --output ./demo-out
```

Open `demo-out/report.html`.

## Scope and scoring

The report evaluates:

1. Monitoring coverage
2. Telemetry depth
3. Detection and alerting
4. Reliability engineering
5. Root-cause analysis
6. Remediation and automation
7. Governance
8. Operational outcomes

Scores range from 0 to 5. The overall score is a weighted average of dimensions with sufficient evidence. `evidenceCompleteness` shows how much of the assessment could be verified.
