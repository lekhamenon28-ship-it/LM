"""Read-only adapters that normalize observability tools into common datasets."""
from __future__ import annotations

import base64
import json
import os
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

from collector import ApiClient, Dataset, safe_collect


class JsonHttp:
    def __init__(self, base: str, headers: dict[str, str], timeout: int = 30):
        self.base, self.headers, self.timeout = base.rstrip("/"), headers, timeout

    def request(self, path: str, params: dict[str, Any] | None = None, body: dict[str, Any] | None = None) -> Any:
        url = self.base + path
        if params:
            url += "?" + urllib.parse.urlencode(params, doseq=True)
        data = json.dumps(body).encode() if body is not None else None
        headers = dict(self.headers)
        if data is not None:
            headers["Content-Type"] = "application/json-rpc"
        req = urllib.request.Request(url, data=data, headers=headers, method="POST" if data is not None else "GET")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")[:600]
            raise RuntimeError(f"HTTP {exc.code}: {detail}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Connection error: {exc.reason}") from exc


def empty(status: str = "available") -> Dataset:
    return Dataset(status, [], "not-applicable", pages=0)


def datadog(timeout: int = 30) -> dict[str, Dataset]:
    base = os.environ.get("DD_SITE", "https://api.datadoghq.com")
    api_key, app_key = os.environ.get("DD_API_KEY"), os.environ.get("DD_APP_KEY")
    if not api_key or not app_key:
        raise RuntimeError("DD_API_KEY and DD_APP_KEY are required")
    client = JsonHttp(base, {"DD-API-KEY": api_key, "DD-APPLICATION-KEY": app_key, "Accept": "application/json"}, timeout)

    def hosts():
        output, start = [], 0
        while True:
            payload = client.request("/api/v1/hosts", {"start": start, "count": 1000, "include_muted_hosts_data": "true"})
            batch = payload.get("host_list", [])
            output.extend({"entityId": f'DD_HOST-{h.get("id", h.get("host_name"))}', "type": "HOST", "displayName": h.get("name", h.get("host_name", "host")), "healthState": "HEALTHY" if h.get("up", True) else "UNHEALTHY", "tags": [{"key": str(t).split(":",1)[0], "value": str(t).split(":",1)[1] if ":" in str(t) else ""} for t in h.get("tags_by_source", {}).get("Datadog", [])], "source": "datadog"} for h in batch)
            start += len(batch)
            if not batch or start >= payload.get("total_matching", start):
                return output, max(1, (start + 999)//1000)

    monitors = safe_collect("datadog monitors", "/api/v1/monitor", lambda: client.request("/api/v1/monitor"))
    monitor_data = monitors.data or []
    return {
        "entities": safe_collect("datadog hosts", "/api/v1/hosts", hosts),
        "metrics": safe_collect("datadog metrics", "/api/v1/metrics", lambda: [{"metricId": x} for x in client.request("/api/v1/metrics", {"from": int(time.time())-86400}).get("metrics", [])]),
        "problems": Dataset(monitors.status, [{"problemId": f'DD-{m.get("id")}', "status": "OPEN" if str(m.get("overall_state", "OK")).lower() not in ("ok", "no data") else "CLOSED", "severityLevel": m.get("priority"), "source": "datadog"} for m in monitor_data], monitors.endpoint, monitors.error, monitors.pages),
        "settings_schemas": empty(),
        "settings_objects": Dataset(monitors.status, [{"schemaId": f'datadog.monitor.{m.get("type","unknown")}', "value": m, "source": "datadog"} for m in monitor_data], monitors.endpoint, monitors.error, monitors.pages),
        "slos": safe_collect("datadog SLOs", "/api/v1/slo", lambda: client.request("/api/v1/slo", {"limit": 1000}).get("data", [])),
        "synthetic_monitors": safe_collect("datadog synthetics", "/api/v1/synthetics/tests", lambda: client.request("/api/v1/synthetics/tests").get("tests", [])),
        "management_zones": empty(), "alerting_profiles": monitors,
        "notifications": Dataset(monitors.status, [m for m in monitor_data if "@" in str(m.get("message", ""))], monitors.endpoint, monitors.error, monitors.pages),
    }


def zabbix(timeout: int = 30) -> dict[str, Dataset]:
    url, token = os.environ.get("ZABBIX_URL"), os.environ.get("ZABBIX_TOKEN")
    if not url or not token:
        raise RuntimeError("ZABBIX_URL and ZABBIX_TOKEN are required")
    if not url.endswith("api_jsonrpc.php"):
        url = url.rstrip("/") + "/api_jsonrpc.php"
    client = JsonHttp(url.rsplit("/", 1)[0], {"Authorization": f"Bearer {token}", "Accept": "application/json"}, timeout)
    counter = [0]

    def rpc(method: str, params: dict[str, Any]):
        counter[0] += 1
        result = client.request("/api_jsonrpc.php", body={"jsonrpc": "2.0", "method": method, "params": params, "id": counter[0]})
        if "error" in result:
            raise RuntimeError(f'Zabbix API {result["error"]}')
        return result.get("result", [])

    host_ds = safe_collect("zabbix hosts", "host.get", lambda: rpc("host.get", {"output": ["hostid", "host", "name", "status", "available"], "selectTags": "extend", "selectHostGroups": ["groupid", "name"]}))
    trigger_ds = safe_collect("zabbix triggers", "trigger.get", lambda: rpc("trigger.get", {"output": ["triggerid", "description", "priority", "status", "value"], "monitored": True, "expandDescription": True, "selectTags": "extend"}))
    problems = safe_collect("zabbix problems", "problem.get", lambda: rpc("problem.get", {"output": "extend", "recent": True, "sortfield": ["eventid"], "sortorder": "DESC", "limit": 5000}))
    item_count = safe_collect("zabbix item count", "item.get", lambda: rpc("item.get", {"countOutput": True, "monitored": True}))
    templates = safe_collect("zabbix templates", "template.get", lambda: rpc("template.get", {"output": ["templateid", "host", "name"]}))
    web = safe_collect("zabbix web scenarios", "httptest.get", lambda: rpc("httptest.get", {"output": ["httptestid", "name", "status"], "selectSteps": ["httpstepid", "name", "url"]}))
    hosts = host_ds.data or []
    triggers = trigger_ds.data or []
    return {
        "entities": Dataset(host_ds.status, [{"entityId": f'ZBX_HOST-{h.get("hostid")}', "type": "HOST", "displayName": h.get("name", h.get("host")), "healthState": "HEALTHY" if h.get("status") == "0" and h.get("available") != "2" else "UNHEALTHY", "tags": h.get("tags", []), "managementZones": [{"name": g.get("name")} for g in h.get("hostgroups", [])], "source": "zabbix"} for h in hosts], host_ds.endpoint, host_ds.error, host_ds.pages),
        "metrics": Dataset(item_count.status, [{"metricId": "zabbix.monitored.items", "count": int(item_count.data or 0)}], item_count.endpoint, item_count.error, item_count.pages),
        "problems": problems,
        "settings_schemas": Dataset(templates.status, [{"schemaId": "zabbix.template", **t} for t in (templates.data or [])], templates.endpoint, templates.error, templates.pages),
        "settings_objects": Dataset(trigger_ds.status, [{"schemaId": "zabbix.trigger", "value": t} for t in triggers], trigger_ds.endpoint, trigger_ds.error, trigger_ds.pages),
        "slos": empty(), "synthetic_monitors": web,
        "management_zones": Dataset(host_ds.status, [g for h in hosts for g in h.get("hostgroups", [])], host_ds.endpoint, host_ds.error, host_ds.pages),
        "alerting_profiles": trigger_ds,
        "notifications": empty("unknown"),
    }


def splunk(timeout: int = 30) -> dict[str, Dataset]:
    base, token = os.environ.get("SPLUNK_URL"), os.environ.get("SPLUNK_TOKEN")
    user, password = os.environ.get("SPLUNK_USER"), os.environ.get("SPLUNK_PASSWORD")
    if not base or (not token and not (user and password)):
        raise RuntimeError("SPLUNK_URL plus SPLUNK_TOKEN, or SPLUNK_USER and SPLUNK_PASSWORD, are required")
    auth = f"Splunk {token}" if token else "Basic " + base64.b64encode(f"{user}:{password}".encode()).decode()
    client = JsonHttp(base, {"Authorization": auth, "Accept": "application/json"}, timeout)

    def entries(path: str):
        return client.request(path, {"output_mode": "json", "count": 0}).get("entry", [])

    server = safe_collect("splunk server info", "/services/server/info", lambda: entries("/services/server/info"))
    indexes = safe_collect("splunk indexes", "/services/data/indexes", lambda: entries("/services/data/indexes"))
    searches = safe_collect("splunk saved searches", "/servicesNS/-/-/saved/searches", lambda: entries("/servicesNS/-/-/saved/searches"))
    dashboards = safe_collect("splunk dashboards", "/servicesNS/-/-/data/ui/views", lambda: entries("/servicesNS/-/-/data/ui/views"))
    fired = safe_collect("splunk fired alerts", "/services/alerts/fired_alerts", lambda: entries("/services/alerts/fired_alerts"))
    index_data, search_data = indexes.data or [], searches.data or []
    entities = [{"entityId": f'SPLUNK_INDEX-{i.get("name")}', "type": "LOG_INDEX", "displayName": i.get("name"), "healthState": "HEALTHY", "tags": [], "source": "splunk"} for i in index_data]
    entities += [{"entityId": f'SPLUNK_SERVER-{s.get("name")}', "type": "LOG_SERVER", "displayName": s.get("name"), "healthState": "HEALTHY", "tags": [], "source": "splunk"} for s in (server.data or [])]
    alerts = [s for s in search_data if str(s.get("content", {}).get("alert_type", "always")) != "always" or str(s.get("content", {}).get("is_scheduled", "0")) == "1"]
    return {
        "entities": Dataset(indexes.status, entities, indexes.endpoint, indexes.error, indexes.pages),
        "metrics": Dataset(indexes.status, [{"metricId": "splunk.index", "name": i.get("name"), "currentDBSizeMB": i.get("content", {}).get("currentDBSizeMB")} for i in index_data], indexes.endpoint, indexes.error, indexes.pages),
        "problems": fired,
        "settings_schemas": Dataset(dashboards.status, [{"schemaId": "splunk.dashboard", "name": d.get("name")} for d in (dashboards.data or [])], dashboards.endpoint, dashboards.error, dashboards.pages),
        "settings_objects": Dataset(searches.status, [{"schemaId": "splunk.saved_search", "value": s} for s in search_data], searches.endpoint, searches.error, searches.pages),
        "slos": empty("unknown"), "synthetic_monitors": empty("unknown"), "management_zones": empty(),
        "alerting_profiles": Dataset(searches.status, alerts, searches.endpoint, searches.error, searches.pages),
        "notifications": Dataset(searches.status, [s for s in alerts if any(str(k).startswith("action.") and str(v) in ("1", "true", "True") for k, v in s.get("content", {}).items())], searches.endpoint, searches.error, searches.pages),
    }


ADAPTERS = {"datadog": datadog, "zabbix": zabbix, "splunk": splunk}

